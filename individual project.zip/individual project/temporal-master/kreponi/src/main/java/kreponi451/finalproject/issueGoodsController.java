package kreponi451.finalproject;

public class issueGoodsController {
}
